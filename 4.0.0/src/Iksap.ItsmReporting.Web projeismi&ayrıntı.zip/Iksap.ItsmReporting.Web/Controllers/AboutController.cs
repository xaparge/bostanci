﻿using System.Web.Mvc;

namespace Iksap.ItsmReporting.Web.Controllers
{
    public class AboutController : ItsmReportingControllerBase
    {
        public ActionResult Index()
        {

            return View();
        }
        
    }
}